import "../detail-team-main.js";
import "../db/idb.js";
import "../api/api-listener.js";
import "../register-service-worker.js";
import "../push/register-notification.js";
