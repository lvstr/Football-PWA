import "./script/main.js";
import "./script/register-service-worker.js";
import "./script/push/register-notification.js";
